package classinherit;

import java.util.*;
import java.io.*;

public class IO {

	public static PrintStream cmd = new PrintStream(System.out);
	public static Scanner arg = new Scanner(System.in);
}