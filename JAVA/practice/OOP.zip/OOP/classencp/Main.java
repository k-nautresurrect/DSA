package classencp;

public class Main {
	public static void main(String[] args) {
		// to show employee salary.
		Employee emp1 = new Employee();
		emp1.setName("Nishant");
		System.out.println(emp1.getName());
	}
}