package classoop;
/*
	class -> naksha
	object -> building

*/


/*
	1. encapsulation - capsulate things.
	2. abstraction
	3. inheritance
*/
public class Main {
	public static void main(String[] args) {
		// classname (identifier) -> object = new <- create an instance classname();
		Hello greet = new Hello();
		System.out.println(greet.Greetings);
	}
}