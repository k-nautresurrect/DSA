package classoop;

public class Hello {
	// if i am taking any identifier (variable, object, constructor) -> field
	public String Greetings = "Hello World"; // Field

}